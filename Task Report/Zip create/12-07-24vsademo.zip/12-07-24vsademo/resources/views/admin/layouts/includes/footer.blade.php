<footer class="footer-content">
    <div class="footer-text d-flex align-items-center justify-content-between">
        <div class="copy">Â© 2018 Bdtask Responsive Bootstrap 4 Dashboard Template</div>
        <div class="credit">Designed by: <a href="#">Bdtask</a></div>
    </div>
</footer><!--/.footer content-->
<div class="overlay"></div>