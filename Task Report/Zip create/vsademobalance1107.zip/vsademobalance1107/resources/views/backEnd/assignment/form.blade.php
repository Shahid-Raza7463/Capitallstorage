
    <div class="form-group">
        <label class="font-weight-600">Name</label>
        <input type="text" name="assignment_name" value="{{ $tab->assignment_name ?? ''}}" class="form-control" placeholder="Enter name">
    </div>
    <button type="submit" class="btn btn-success">Submit</button>
