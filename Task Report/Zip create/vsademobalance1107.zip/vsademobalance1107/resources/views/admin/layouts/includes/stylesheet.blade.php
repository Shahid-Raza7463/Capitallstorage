
  <!-- App favicon -->
  <link rel="shortcut icon" href="{{ url('backEnd/image/kgsomani.png')}}">
  <!--Global Styles(used by all pages)-->
  <link href="{{ url('backEnd/plugins/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{ url('backEnd/plugins/metisMenu/metisMenu.min.css')}}" rel="stylesheet">
  <link href="{{ url('backEnd/plugins/fontawesome/css/all.min.css')}}" rel="stylesheet">
  <link href="{{ url('backEnd/plugins/typicons/src/typicons.min.css')}}" rel="stylesheet">
  <link href="{{ url('backEnd/plugins/themify-icons/themify-icons.min.css')}}" rel="stylesheet">
  <!--Third party Styles(used by this page)--> 
  <link href="{{ url('backEnd/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet">
  <!--Start Your Custom Style Now-->
  <link href="{{ url('backEnd/dist/css/style.css')}}" rel="stylesheet">

  

  