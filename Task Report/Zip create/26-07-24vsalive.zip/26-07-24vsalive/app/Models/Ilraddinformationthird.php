<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ilraddinformationthird extends Model
{
    use HasFactory;
    protected $table = 'ilraddinformationthird';
    protected $guarded = [];
}
